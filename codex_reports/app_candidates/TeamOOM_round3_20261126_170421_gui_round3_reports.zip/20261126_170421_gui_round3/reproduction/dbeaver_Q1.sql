COPY (
    SELECT ID, CAST(strptime(DATE, '%Y%m%d') AS DATE) AS DATE,
           ELEMENT, DATA_VALUE, Q_FLAG,
           CAST(DATA_VALUE AS DOUBLE) / 10.0 AS CONVERTED_VALUE,
           CASE WHEN ELEMENT = 'PRCP' THEN 'mm' ELSE 'degC' END AS UNIT
    FROM read_csv('/home/mxt/TeamOOM/assets/real_cases/app_candidates/shared_assets/weather/2024_Q1_header.csv', header = true, nullstr = '',
        columns = {'ID':'VARCHAR','DATE':'VARCHAR','ELEMENT':'VARCHAR',
                    'DATA_VALUE':'INTEGER','M_FLAG':'VARCHAR','Q_FLAG':'VARCHAR',
                    'S_FLAG':'VARCHAR','OBS_TIME':'VARCHAR'})
    WHERE (Q_FLAG IS NULL OR trim(Q_FLAG) = '')
      AND ELEMENT IN ('TMAX','TMIN','TAVG','PRCP')
    ORDER BY ID, DATE, ELEMENT
) TO '/home/mxt/TeamOOM/results/app_candidates/20261126_170421_gui_round3/outputs/dbeaver_Q1.parquet' (FORMAT PARQUET, COMPRESSION ZSTD);
