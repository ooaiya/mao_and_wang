SET threads=4;
SET memory_limit='6GB';
SET temp_directory='/home/mxt/TeamOOM/runtime/config/app_candidates/round3/duckdb_tmp';
SET enable_profiling='json';
SET profiling_output='/home/mxt/TeamOOM/data_collection/app_candidates/20261126_170421_gui_round3/dbeaver/round_01/duckdb_profile.json';
SELECT version() AS version, current_setting('threads') AS threads, current_setting('memory_limit') AS memory_limit, current_setting('temp_directory') AS temp_directory;
