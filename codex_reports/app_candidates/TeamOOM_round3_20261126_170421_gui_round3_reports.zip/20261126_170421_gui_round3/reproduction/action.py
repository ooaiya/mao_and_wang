import sys,json,subprocess
from pathlib import Path
R=Path('/home/mxt/TeamOOM');B=json.loads((R/'runtime/config/app_candidates/round3/batch.json').read_text())['batch'];app,round_,op=sys.argv[1:4];args=sys.argv[4:];folder=R/'data_collection/app_candidates'/B/app/round_
if op=='launch':cmd=['/usr/bin/python3',str(R/'repo/tools/real_app_candidates/launch.py'),'--application',app,'--directory',str(folder),'--',*args]
elif op=='event':cmd=['/usr/bin/python3',str(R/'repo/tools/real_app_candidates/capture.py'),'--directory',str(folder),'--event',args[0],'--detail',args[1]]
elif op=='close':
 subprocess.run(['/usr/bin/python3',str(__file__),app,round_,'event','app_close','Application close requested after task completion and natural-release observation'],check=True)
 unit=json.loads((folder/'environment.json').read_text())['unit'];cmd=['systemctl','--user','stop',unit]
else:cmd=['/usr/bin/python3',str(R/'repo/tools/real_app_candidates/gui.py'),'--log',str(folder/'gui_actions.jsonl'),op,*args]
subprocess.run(cmd,check=True)
