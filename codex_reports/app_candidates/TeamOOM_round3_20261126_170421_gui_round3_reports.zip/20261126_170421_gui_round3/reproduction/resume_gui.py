import os,subprocess,sys,json,time,datetime
from pathlib import Path
for line in subprocess.check_output(['systemctl','--user','show-environment'],text=True).splitlines():
 k,_,v=line.partition('=')
 if k in {'DISPLAY','XAUTHORITY','DBUS_SESSION_BUS_ADDRESS','XDG_RUNTIME_DIR'}:os.environ[k]=v
op,*args=sys.argv[1:];start=time.monotonic_ns()
if op=='click':cmd=['xdotool','mousemove','--sync',args[0],args[1],'sleep','0.4','click','1']
elif op=='key':cmd=['xdotool','key',*args]
elif op=='focus':cmd=['wmctrl','-a',args[0]]
elif op=='shot':cmd=['gnome-screenshot','-f',args[0]]
elif op=='close':cmd=['wmctrl','-ic',args[0]]
elif op=='windows':cmd=['wmctrl','-lpG']
else:raise ValueError(op)
subprocess.run(cmd,check=True)
if op in {'click','key','focus'}:time.sleep(.7)
with Path('/home/mxt/TeamOOM/data_collection/app_candidates/20261126_170421_gui_round3/hop/round_03_corrected/gui_actions.jsonl').open('a') as f:f.write(json.dumps({'monotonic_ns':start,'end_monotonic_ns':time.monotonic_ns(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operation':op,'arguments':args,'backend':'native X11 xdotool/wmctrl'})+'\n')
