# 第三轮复现与续接

根目录 `/home/mxt/TeamOOM`。本批次 `20261126_170421_gui_round3`，续接只运行 Hop。PeaZip、DBeaver 的第三轮和 HandBrake 第二轮有效数据由 `selected_rounds.json` 明确引用。

Hop 使用官方2.20.0、DBeaver自带Temurin21.0.8+9、独立项目与配置、2GiB JVM堆、1000000行排序缓冲。JVM堆不是cgroup内存限额；memory.max/high必须为max。源CSV为共享NOAA Q1原始筛选数据，9,579,563行。使用 `repo/tools/real_app_candidates/configure_hop.py` 生成新项目（不得覆盖已有路径），安装目录和真实输入在software_assets_parameters.json。用 `launch.py --application hop --directory 新的外部轮次目录 -- /usr/bin/env HOP_JAVA_HOME=... HOP_CONFIG_FOLDER=... HOP_AUDIT_FOLDER=... 'HOP_OPTIONS=-Xmx2048m -Djava.io.tmpdir=...' /bin/sh .../hop-gui.sh -j=weather -f=...hpl` 启动。

打开Hop GUI，确认流水线尚未执行，Run→local→Launch。此操作由真实GUI提交；不调用hop-run。随后激活独立前台窗口并保存截图。`capture.py`在独立用户systemd服务中以50ms目标采集整个应用cgroup，`watch_artifact.py`在提交前启动，观察真实输出fd从打开到关闭；保存原生完成日志，区别于GUI退出。

原生链：CSVInput→SelectValues（日期yyyyMMdd，保留原值Integer）→FilterRows（空Q_FLAG且TMAX/TMIN/TAVG/PRCP）→Calculator（Number常量0.1位于乘法左侧）→Formula（PRCP=mm，其余degC）→SortRows（ID/DATE/ELEMENT）→TextFileOutput。拒绝记录进入Dummy。Calculator按左操作数类型进行算术；不得使用原Integer/10，即使结果声明为Number也会截断。正确示例236→23.6、278→27.8。

完成后保持JVM原状观察自然内存变化，不强制GC、不重置节点、不清缓存。使用verify_weather.py对真实Q1输入和完整CSV输出进行全部行数、单位、数值、排序、sum/xor SHA256记录指纹检查。GUI成功不能代替业务核验。之后通过GUI正常退出并保留退出尾段。

round_01因用户个人时间暂停而排除，明确不是程序错误。round_02_resumed原生运行成功但独立验证发现整数截断，排除并保留证据；round_03_corrected为最终正式轮次。所有原始采样保持原文件，不拼接、删段或改写。未绘制被排除轮次为成功结果。

分析：`MPLCONFIGDIR=/tmp/teamoom-mpl runtime/venv/bin/python repo/tools/real_app_candidates/compare_rounds.py --generic --manifest results/app_candidates/20261126_170421_gui_round3/selected_rounds.json --output results/app_candidates/20261126_170421_gui_round3/analysis`。先核验业务再分析。运行 `runtime/venv/bin/python -m unittest discover -s repo/tests -v`。Python仅用于配置、采集、独立验证与离线绘图，不执行业务ETL。

完整样本在data_collection，不打包大体积软件、业务输出或气象素材。报告ZIP包含报告、曲线、指标、小型配置、验证和复现证据。主机名/IP参见download_instructions.md；宿主机Downloads目标在PowerShell使用USERPROFILE。
