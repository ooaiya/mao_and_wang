# Windows 宿主机下载

VM当前IPv4为192.168.50.100。请在宿主机PowerShell执行（写入当前Windows用户Downloads）：

```powershell
scp mxt@192.168.50.100:/home/mxt/TeamOOM/results/app_candidates/TeamOOM_round3_20261126_170421_gui_round3_reports.zip "$env:USERPROFILE\Downloads\"
scp mxt@192.168.50.100:/home/mxt/TeamOOM/results/app_candidates/TeamOOM_round3_20261126_170421_gui_round3_reports.zip.sha256 "$env:USERPROFILE\Downloads\"
Get-FileHash "$env:USERPROFILE\Downloads\TeamOOM_round3_20261126_170421_gui_round3_reports.zip" -Algorithm SHA256
```

SHA256应与下载的.sha256文本一致。若VM地址后续变化，用新的实际地址替换。无需依赖共享目录。
