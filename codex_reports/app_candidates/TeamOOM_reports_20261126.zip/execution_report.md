# 六个真实后台应用：部署、单轮采集与筛选报告

执行日期：2026-11-25～2026-11-26，Asia/Shanghai。批次 `20261125_194918_gui`。

六个应用均已部署、通过真实 GUI 提交业务计算，并保存真实输出及内存数据。共保留15次尝试；有7段经输出验证的完整计算（含 Classroom32/16spp），选6段作最终比较。没有运行 Krita 压力、正式并发、调度策略或 HistoricalLookup 接入。

本轮没有选出分别满足 Raster、Table、Array 的三个合格应用。Classroom16spp 是优先保留的 Array 部分匹配，HandBrake/Kdenlive 可作 Array 备用；PeaZip 有 Raster 的阶梯增长特征但当前数值和释放残留不足以验收；Table 仍缺候选。这里只给探索性筛选，未强行指定三应用。

## 1. 实测交付表

| 应用 | 实际操作 | 峰值GiB | 达峰秒 | 95%平台秒 | 释放形态 | 任务耗时秒 | 是否正常完成 | 最匹配目标 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Blender | Classroom 单帧 CPU 渲染，1280×720 / 16 spp | 0.821 | 76.77 | 40.61 | 结束时阶跃下降，再短时下降；GUI 保留约0.47GiB | 78.38 | 是 | Array（部分） |
| Hugin | 25 张 2560×1920 原片，全景重映射与融合 | 1.047 | 172.29 | 10.25 | 计算中周期性锯齿，结束集中释放 | 222.7 | 是 | Raster（弱） |
| darktable | 3 张兼容 Canon RAW → 原尺寸 JPEG95 | 1.338 | 13.53 | 7.15 | 逐张脉冲，完成集中释放 | 14.05 | 是（缩小为3张） | Array（弱） |
| Kdenlive | 120 秒 1080p30，2 视频＋2 音轨画中画 → H.264/AAC | 1.602 | 257.03 | 98.68 | 渲染子进程退出时集中释放；GUI 约0.66GiB | 257.9 | 是 | Array（部分） |
| HandBrake | BBB 前120秒，1080p30 → x265 Medium RF22 MKV | 1.005 | 268.29 | 197.15 | 编码结束集中释放；GUI 约0.34GiB | 269.65 | 是 | Array（部分） |
| PeaZip | 17 个真实素材文件（1.116 GiB）→ 7z LZMA2 Normal | 2.402 | 100.5 | 12.35 | 结束集中释放匿名内存；约1.09GiB文件缓存保留 | 100.95 | 是 | Raster（部分） |

“最匹配目标”是综合峰值量级、初期增长、高位区间及自然释放后的相对建议，不表示已匹配验收。任务耗时从最后一次有效 GUI 提交到原生完成日志/回调/计算子进程结束；不含素材加载与完成后空闲。darktable 原较大批次未完成，表内明确只代表3张兼容照片。

达峰时间是**采样全局最大值**出现时刻。接近平台的轻微后续增长也会使其接近任务末尾，不能替代初期增长速度。95%平台采用计算区间内 `memory.current≥0.95×该段峰值` 的实际时间间隔之和（按左端采样值近似保持至下一采样，缺口带来额外估算不确定性）；同时保存最长连续区间，不把完成后的空闲或退出后的时间算作计算平台。

## 2. 文件入口与完整曲线

- [最终六应用叠加对比](analysis/all_apps_common_scale.png)；[完整生命周期同坐标图](analysis/six_apps_full_lifecycle_common_scale.png)。
- [匿名内存/文件缓存同坐标分解](analysis/six_apps_anon_file_common_scale.png)。
- [最终表 CSV](final_summary.csv)；[全部轮次指标 JSON](analysis/metrics.json)；[首轮六应用分析，补采前保留](analysis_first_six/metrics.json)。
- [软件/素材/参数及输出校验](software_assets_parameters.json)；[原始CSV完整性与进程归属检查](raw_capture_audit.json)。
- 原始采样根目录：`/home/mxt/TeamOOM/data_collection/app_candidates/20261125_194918_gui/`。每轮保留 `task_memory.csv`、`process_tree.csv`、`phase_trace.jsonl`、`environment.json`、应用日志；支持时还保留祖先限制和采集摘要。原始CSV未插值、补零或补造缺列。

- Blender：[round_03 完整曲线](analysis/blender_round_03.png)；[原始CSV](/home/mxt/TeamOOM/data_collection/app_candidates/20261125_194918_gui/blender/round_03/task_memory.csv)。
- Hugin：[round_04 完整曲线](analysis/hugin_round_04.png)；[原始CSV](/home/mxt/TeamOOM/data_collection/app_candidates/20261125_194918_gui/hugin/round_04/task_memory.csv)。
- darktable：[round_03 完整曲线](analysis/darktable_round_03.png)；[原始CSV](/home/mxt/TeamOOM/data_collection/app_candidates/20261125_194918_gui/darktable/round_03/task_memory.csv)。
- Kdenlive：[round_02 完整曲线](analysis/kdenlive_round_02.png)；[原始CSV](/home/mxt/TeamOOM/data_collection/app_candidates/20261125_194918_gui/kdenlive/round_02/task_memory.csv)。
- HandBrake：[round_01 完整曲线](analysis/handbrake_round_01.png)；[原始CSV](/home/mxt/TeamOOM/data_collection/app_candidates/20261125_194918_gui/handbrake/round_01/task_memory.csv)。
- PeaZip：[round_02 完整曲线](analysis/peazip_round_02.png)；[原始CSV](/home/mxt/TeamOOM/data_collection/app_candidates/20261125_194918_gui/peazip/round_02/task_memory.csv)。

![六应用实测对比](analysis/all_apps_common_scale.png)

逐轮完整图包含启动/加载、计算、计算结束后自然释放、关闭请求和推断实际退出。darktable的负时间段还包含此前失败的10张导出尝试，不是全都被标为“加载”。六图使用相同横纵范围；叠加图从计算提交起并只显示完成后最多60秒，完整生命周期图保留全部空闲和关闭过程。

## 3. 增长、平台、释放与三个目标

| 应用 | 10→90%增长秒 | 首次95%秒 | 最长95%秒 | anon峰值GiB | file峰值GiB | 关闭前GiB | 判定 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Blender | 4.90 | 37.41 | 40.61 | 0.816 | 0.002 | 0.466 | 部分匹配：优先保留 Array 候选 |
| Hugin | 86.00 | 171.14 | 2.10 | 0.844 | 0.277 | 0.098 | 不匹配：当前业务锯齿明显，缺连续平台 |
| darktable | 1.95 | 2.08 | 3.20 | 1.305 | 0.036 | 0.262 | 不匹配：仅小批次完成，原批次存在解码失败 |
| Kdenlive | 7.97 | 158.39 | 98.68 | 1.491 | 0.098 | 0.659 | 部分匹配：更偏 Array，当前不适合 Table |
| HandBrake | 4.89 | 72.49 | 197.15 | 0.942 | 0.056 | 0.339 | 部分匹配：Array 备用，平台过长 |
| PeaZip | 84.27 | 88.20 | 12.35 | 1.287 | 1.091 | 1.148 | 部分匹配：偏 Raster，峰值与平台不足 |

anon 和 file 的最大值可能发生在不同时间，不能直接把两个最大值相加当作总峰值。内核开销与读取时序也使分解不必逐点精确相加。文件缓存已有归属时，后续 cgroup 暖读不会重新计费；本轮没有清全局缓存。

Classroom32spp→16spp唯一补采：耗时148.25→78.38秒，95%区间85.76→40.61秒；总峰值0.988→0.821GiB，匿名峰值0.814→0.816GiB，file峰值0.172→0.002GiB。**峰值降低主要来自文件缓存计费状态变化，不能归因于采样数。** 16spp初期约4.90秒达到90%绝对峰值，但随后缓慢爬升，首次95%仍要37.41秒、全局最大值在76.77秒。释放有完成时阶跃及短时继续下降，但仍保留GUI内存。因此没有认定为完整Array匹配。两张均是带Monte Carlo噪声的真实预览渲染输出。

HandBrake/Kdenlive初期增长较快，但高位区间约197/99秒，且主要在计算结束集中释放，当前都没有Table约4GiB且逐步释放的特征。Hugin约1GiB的峰值由反复融合工作产生，95%区间很碎，最长仅2.10秒。PeaZip约1.29GiB匿名内存之外，写出的压缩包形成约1.09GiB阶梯增长的文件缓存，计算结束后缓存仍保留；不能把后续cgroup删除当作这些页面都已回收。

以下为只用用户提供三项标量计算的描述性距离：`Σ|ln(实测/目标)|`，等权，越小越接近。它**不是曲线形态相似度**，会因“平台末端才出现全局最大值”而偏向Raster，不能拿最小值强行通过筛选。每个应用都与三个目标比较：

| 应用 | Raster | Table | Array | 三标量最小 | 综合形态建议 |
| --- | --- | --- | --- | --- | --- |
| Blender | 2.430 | 2.480 | 3.504 | Raster | Array（部分） |
| Hugin | 4.270 | 4.296 | 5.504 | Raster | Raster（弱） |
| darktable | 3.629 | 3.684 | 3.564 | Array | Array（弱） |
| Kdenlive | 3.858 | 3.907 | 5.604 | Raster | Array（部分） |
| HandBrake | 5.059 | 5.109 | 5.897 | Raster | Array（部分） |
| PeaZip | 2.715 | 2.741 | 5.609 | Raster | Raster（部分） |

目标原始历史CSV未在本项目 `inputs`、`assets/baseline_assets`、当前数据树、main/origin/main文件树找到；仅有旧档案SHA清单不能当作原始曲线。没有生成假目标时间序列，也未报告DTW或相关系数。使用任务书的峰值/达峰/95%平台及增长、释放描述作比较。

## 4. 实际软件、素材与业务配置

- Blender2.92.0为官方便携版。Agent327原件SHA256 `95972b56180462cac47ec82f3a755bd9111ec18ca37a6196a319c013db994130`，原件未覆盖。正常16GB环境下成功加载，并通过F12启动CPU渲染准备；实际继承Branched Path Tracing32AA（最初写入cycles.samples=16不控制此模式，已在原始事件中纠正）。可用内存低于2GiB时安全中止，实测10.331GiB峰值，未得输出；没有再对该场景反复尝试。
- 替代素材是[Blender官方Classroom ZIP](https://download.blender.org/demo/test/classroom.zip)，70279690字节，SHA256 `0f0ecc58d45f12b2f4272a53e2d8e69135518e16e956b118f10c20d8dcfdf5e6`，ZIP CRC通过。它不是来自第三方重新打包。保留其11个相对链接素材库，CPU PATH1280×720，32spp首轮及16spp一次补采。下载SHA为本地完整性指纹，不冒充发行方签名。
- Hugin2019.2.0为官网指向维护者渠道的第三方AppImage，解包运行。Ubuntu当前索引无安装候选，所以使用兼容便携构建。素材是固定提交的公开[HuginSample](https://github.com/niebert/HuginSample/tree/c26c836220e2d6845e1c9b88cc3c254cf43c088b)，Durlach Saumarkt25张原片。专家界面加载后GUI运行CPFind，Ctrl+T几何优化，保存PTO；PTBatcherGUI提交nona+enblend，11618×5809画布裁切10978×3398，TIFF LZW。输出89326008字节，完整解码；优化RMS约37.96px及接缝优化警告保留，预览完整不代表测量级几何精度。
- darktable3.8.1-2。原[公开RAW样本包](https://github.com/tellodaniel/revelraw-sample-raw-files/releases/download/v1/revelraw-sample-raw-files-all.zip)14张；OM1无解码器、Apple/DJI DNG预测模式不支持、Fuji压缩RAF头校验失败。最终只导出Canon5D-IV CR2、D60 CRW、EOSR CR3，发布方SHA256SUMS核对通过，JPEG8bit质量95，原尺寸，不放大。三个结果分别6744×4500、3080×2046、6720×4480，全部完整解码。未把其余未执行照片算成功。
- Kdenlive21.12.3，MLT7.4.0，补装Ubuntu源Frei0r1.7.0-2build1及mediainfo22.03-1。两真实影片为Blender官方[BBB1080p](https://download.blender.org/demo/movies/BBB/bbb_sunflower_1080p_30fps_normal.mp4.zip)及[ToS1080p](https://download.blender.org/demo/movies/ToS/tears_of_steel_1080p.mov.zip)，后者实际1920×800。项目1920×1080/30fps/120秒，BBB从60秒起、ToS从100秒起，后者缩至右下角画中画；2视频轨+2音轨。实际消费者参数libx264/CRF23/preset=faster/threads=0自动/real_time=-3/AAC192k/faststart。原生MLT已保存，输入是正常真实视频而非合成占用。
- HandBrake1.5.1，GUI中BBB0–120秒，H.265/x265 Medium/RF22，1080p30，MKV；实际3598帧、输出120.021秒，编码原生日志work result=0。GUI确认比原生日志晚约39秒，指标以20:18:10日志结束（约1秒精度）细化，原GUI事件保留。完整解码通过。
- PeaZip11.4.0官方GTK2便携版，GUI选择上述两影片及RAW素材文件夹，共17文件/1198502763字节，7z/LZMA2/Normal/32MiB字典/solid。实际压缩包1170494676字节，原生7z测试Everything is Ok，17文件。压缩效果有限是因为素材本来已有压缩，不是生成伪素材。

完整URL、版本、素材和输出SHA256、参数、原生MLT及校验记录见 `software_assets_parameters.json` 和各 `*_output_verification.json`；媒体/工程/采样/日志均留在仓库外。

## 5. GUI自动化与复现

运行环境是原有GNOME Wayland会话下的XWayland真实桌面，没有Xvfb。通过用户systemd manager获取DISPLAY/XAUTHORITY，使用pyautogui和wmctrl操作真实窗口，截图保留。录制操作屏幕约2558×1200，不同布局先核对截图再使用坐标。每次只运行一个候选计算。

通用源码位于 `repo/tools/real_app_candidates/`：`launch.py`启动独立GUI服务和脱离终端的采集器；`capture.py`读取50ms cgroup v2；`gui.py`记录真实点击/按键；`watch_workers.py`或`watch_log.py`记录原生完成证据；`configure_blender.py`只配置CPU场景及完成回调；`configure_kdenlive.py`只配置原生项目，不提交渲染；`analyze.py`绘图和计算指标。

Blender经F12提交，完成回调只保存真实Render Result。Hugin从保存的真实控制点工程经批处理GUI的Play提交，编辑器/控制点准备与最终拼接轮分开存档。darktable导入后GUI选择实际照片、设置JPEG95路径、Ctrl+E或Export提交，失败后另选已验证三张的提交时间是最终计算起点。Kdenlive通过Ctrl+Enter打开渲染对话框，选择MP4-H264/AAC并点击Render to File。HandBrake从GUI设置时间范围/视频编码，点击Start。PeaZip从GUI设置7z/LZMA2/Normal，点击OK压缩。每一成功任务都在提交后切换Files窗口并确认继续计算。

本机实际配置脚本与早期启动/GUI助手副本位于 `reproduction/`，对应命令可从每轮 `environment.json`、GUI动作JSONL和阶段事件读取。新轮次示例：

```bash
python3 /home/mxt/TeamOOM/repo/tools/real_app_candidates/launch.py --application kdenlive --directory /home/mxt/TeamOOM/data_collection/app_candidates/NEW_BATCH/kdenlive/round_01 -- /usr/bin/kdenlive /external/project.kdenlive
python3 /home/mxt/TeamOOM/repo/tools/real_app_candidates/capture.py --directory /external/round --event task_submit --detail 'GUI Render to File, verified actual parameters'
```

Blender配置JSON提供 `capture_directory/output/parameters_output/width/height/samples`，以TEAMOOM_BLENDER_CONFIG环境变量传入，然后 `blender --disable-autoexec scene.blend --python configure_blender.py`，仍通过GUI F12开始。不要通过脚本调用render替代GUI提交。不要在已有轮目录覆盖重采。

分析复现：

```bash
MPLCONFIGDIR=/home/mxt/TeamOOM/runtime/config/matplotlib /home/mxt/TeamOOM/runtime/venv/bin/python /home/mxt/TeamOOM/repo/tools/real_app_candidates/analyze.py --data-root /home/mxt/TeamOOM/data_collection/app_candidates/20261125_194918_gui --output /home/mxt/TeamOOM/results/app_candidates/REANALYSIS --selection selected_rounds.json
```

## 6. 采样质量、安全及边界

名义16GB虚拟机，MemTotal实际15.580GiB、4CPU，原内核及约2GiB Swap保持不变。未设置4/8GiB或其他人为memory.max、未设置memory.high，候选叶cgroup均记录max/max，后续轮的祖先也记录max。采集器只在MemAvailable<2GiB、OOM增加或观察到派生进程逃逸时中止当前应用，属于整机保护，不是内存节流。

| 应用 | 总样本 | 均值ms | p95ms | 最大ms | >100ms总数 | 计算段>100ms | 最小可用GiB | OOM增量 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Blender | 6757 | 50.002 | 50.554 | 62.71 | 0 | 0 | 11.734 | 0 |
| Hugin | 9031 | 50.255 | 50.512 | 837.45 | 4 | 3 | 12.067 | 0 |
| darktable | 3101 | 50.438 | 50.540 | 747.27 | 2 | 0 | 11.507 | 0 |
| Kdenlive | 9526 | 50.028 | 50.872 | 289.28 | 1 | 0 | 11.295 | 0 |
| HandBrake | 14085 | 50.418 | 50.656 | 810.73 | 12 | 4 | 12.055 | 0 |
| PeaZip | 3611 | 50.456 | 51.052 | 825.15 | 3 | 2 | 12.118 | 0 |

实际采样间隔约50ms，少量间隔约0.8秒的缺口已如实报告，不插值遮盖。15次尝试的CSV时间戳均严格递增，原始采样SHA已记录；观测到的进程归属均在其应用cgroup。进程普查约1秒一次，不能据此声称捕捉到所有不足1秒的短子进程。memory.peak可用，采样峰值和内核全轮峰值分别保留。

HandBrake与PeaZip的早期CSV只有系统SwapTotal/SwapFree存量，没有pswpin/out及cgroup Swap三列；这些字段明确记为不可用，不能因存量几乎不变就声称没有交换。其余成功轮cgroup Swap峰值0，所选轮的系统换入页数分别Blender16spp0、Hugin0、darktable1、Kdenlive4，换出0；这是各轮观测窗口的整机活动，不归因于该应用。32spp首轮还有503页整机换入，保留在首轮指标。正常Agent327失败轮无新增OOM，安全中止时可用内存1.995GiB。

完成后的自然释放观察窗口在本批次并不等长（约39～254秒）；全部独立标注且不计入计算时长/95%平台。应用的GUI基线或缓存自然保留不等于主动“持有内存”制造曲线。关闭请求 `app_close` 与实际退出边界 `app_exit_inferred` 区分；后者根据最后非零pids.current至首次零/组删除推断，原事件明确记录来源及误差，不冒充GUI直接观测。PeaZip没有直接关闭请求时刻，只记录推断退出；此前表述不补造。

关闭后若叶cgroup删除，memory.current不再可读，原始CSV止于最后真实读数；不追加伪零点。图中实际进程消失前的匿名释放和剩余file值保留，文件缓存可被内核重归属，不能把“应用已退出”解释成全部缓存已回收。Kdenlive关闭SIGTERM后仍存活一段时间，最终GUI退出，过程完整采样并与计算完成区分。

## 7. 失败、改动与中断记录

| 尝试 | 原因及处理 | 数据处理 |
|---|---|---|
| Blender Agent327 round01 | 原件可正常加载；GUI CPU渲染准备升至10.331GiB，MemAvailable<2GiB安全中止 | 完整失败曲线保留；不是先前4GiB审核OOM，不再重审元数据 |
| Hugin round01/02 | 快速预览/兼容启动失败 | 两次失败、日志和截图保留 |
| Hugin round03 | 专家界面完成25张控制点检测与几何优化；主编辑器拼接路径没产生可用执行任务 | 约96分钟准备/空闲及尝试保留；未将其当成功拼接曲线 |
| Hugin round04 | 使用相同版本原生PTBatcherGUI，手动Play成功执行nona/enblend | 只将此完整拼接计算用于统计 |
| PeaZip round01 | 早期采集器中断/不完整，真实业务输出不能代替完整采样 | invalid_capture.md排除，round02完整重采 |
| darktable round01 | 先排除OM1，但Apple DNG预测模式7解码失败、整批终止 | 失败保留，无输出成功声明 |
| darktable round02 | 三Canon成功后DJI DNG预测模式6失败 | 三个中间输出保留，整批不算正常完成 |
| darktable round03首段 | 排除DNG/OM1后，Fuji压缩RAF头校验失败 | 原10张提交及失败事件保留 |
| darktable round03末段 | GUI选择已验证的3张Canon，新输出目录，全部成功 | 以最后一次提交到相应完成测量，原前段仍在完整图中 |
| Kdenlive round01 | 中断时自动审批服务额度耗尽，渲染提交命令没有执行；恢复时仍停留导出对话框 | 约2小时15分钟总采集且无task_submit，invalid标记保留，用户建议后重采round02 |
| Kdenlive round02 | 正常重启并渲染；选择编码格式后对话框布局变化，原意设4线程的输入误改输出到/home/mxt/4，实际线程仍auto | 原生MLT/日志揭示后纠正实际参数，计算继续；成功后移动MP4至指定results目录，没有掩盖参数差异 |
| Classroom32→16spp | 六应用首轮分析完成后，唯一一次正常参数调整 | 原32spp原始数据和analysis_first_six原样保留 |

Hugin关闭快捷键未退出空闲批处理GUI，它与Agent327加载短暂重叠，Hugin计算已结束；随后清理其unit。这一流程偏差保留在事件里，不宣称所有GUI存活期绝对无交叠；所有候选**计算阶段**逐个执行。未运行Krita前台高压。

Kdenlive重采排除了长空闲对启动/加载曲线及缓存状态的混杂。未提交前的空闲不会直接进入独立计算窗口，但不能当作一次干净完整轮次。新轮重启应用和用户缓存目录，保留系统现有缓存状态；没有清缓存、改变Swap或重置VM容量。

## 8. 保留、调整与替代建议

- 优先保留Classroom16spp作为Array部分匹配候选；32spp是保留的原首轮参照。HandBrake作为Array备用，可将真实片段正常缩短以缩短高位计算平台；本轮没有再改它反复补采。
- PeaZip仅作为Raster部分候选：真实业务确实产生阶梯增长，但当前仅2.40GiB、平台12秒且结束后file缓存保留，不能拿它充当3.82GiB目标已匹配。后续应优先选择更合适真实工程文件而非人为占内存。
- Kdenlive正常可用，但当前1.60GiB、快速增长/集中释放更像Array一类，不符合原Table。仅增加时长通常拉长平台，不保证提高峰值；若重选，应使用真实4K多轨素材，仍需实测。
- darktable先解决版本/相机解码兼容并选择更多有效原片；当前3张小批次没有筛选说服力。增加串行张数不必然提高峰值，不能只靠照片数量推断能到4GiB。
- Hugin当前25张拼接曲线为周期性锯齿，建议替换其目标操作或候选；不是因为没有产出而淘汰。

没有三个合格应用时，下一批建议优先验证两个新的真实GUI操作，以下是**未实测假设**，不承诺峰值或释放形态：

1. **Siril真实天文影像序列配准/带剔除叠加**。官方文档提供GUI叠加流程和真实序列处理；按真实帧数、分辨率及叠加算法改变业务规模，观察多图缓冲与分块自然释放，作为Table缺位的探索方向。依据：[官方叠加文档](https://siril.readthedocs.io/en/stable/preprocessing/stacking.html)、[官方手动预处理教程](https://siril.org/tutorials/tuto-manual/)。这里仅从算法业务结构推断其值得筛选，不把文档当作内存曲线证据。
2. **FreeCAD FEM经GUI调用CalculiX做真实工程模型求解**。GUI可启动独立求解子进程，正常网格/求解配置能改变真实问题规模，可独立验证任务完成时的释放，作为Raster的候选方向。依据：[FreeCAD官方仓库的求解器说明](https://github.com/FreeCAD/FreeCAD-documentation/blob/main/wiki/FEM_SolverCalculixCxxtools.md)、[官方FEM说明](https://github.com/FreeCAD/FreeCAD-documentation/blob/main/wiki/FEM_CalculiX.md)。应使用真实工程模型，从能独立完成的规模开始；不能预先声称其达到4GiB或匹配Raster。

后续先补齐Table/Raster合适实例，再采多轮历史曲线、接预测器/启动偏移与三组正式对照；本轮未执行这些步骤。

## 9. 代码与Git

代码仅在mxt修改；Markdown执行汇报提交mxt_codex。main未修改，保留pre-commit/pre-push hooks。工具复用既有monitor的meminfo读数能力，但不修改原预测器/调度实现。17项项目根测试通过，另验证输出目录拒绝写入Git、采集CSV完整性和真实输出。媒体/素材、原始数据、PNG、日志、配置快照均在TeamOOM仓库外，没有作为Git数据提交。

详细Git提交和推送状态保存在本目录 `git_delivery.json`（交付结束时写入）。
